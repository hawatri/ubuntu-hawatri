#!/bin/bash

sudo systemctl start media-drive.mount
sudo systemctl start media-mainpool.mount
sudo systemctl start media-images.mount
sudo systemctl start media-fcp.mount
