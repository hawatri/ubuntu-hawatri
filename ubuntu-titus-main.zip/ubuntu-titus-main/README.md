# Ubuntu-titus
Ubuntu customizations from Chris Titus Tech
 
## Requirements
_This is a Ubuntu server build_

### Download Ubuntu Server

Download from <https://ubuntu.com/download/server> and install the ISO using any imaging tool. 

### Installation Guide

```
git clone https://github.com/ChrisTitusTech/ubuntu-titus
cd ubuntu-titus
sudo ./install.sh
```

